#ifndef DOT_H
#define DOT_H

#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

using namespace std; 	

class Dot{
public:
	vector<double> dotContent;

 Dot(int numberOfDim);
 void print();

};

#endif
