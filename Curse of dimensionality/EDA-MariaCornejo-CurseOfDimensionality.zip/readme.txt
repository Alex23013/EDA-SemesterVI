Compilar con los siguientes flags
g++ -std=c++11 main.cpp dot.h dot.cpp array.h array.cpp

